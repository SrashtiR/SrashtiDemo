package com.example.srashtidemoapp.presentation.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.srashtidemoapp.R
import com.example.srashtidemoapp.domain.model.Holding

class HoldingsAdapter(
    private val holdings: List<Holding>,
    private val expandedState: MutableSet<Int>
) : RecyclerView.Adapter<HoldingsAdapter.HoldingViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HoldingViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_holding, parent, false)
        return HoldingViewHolder(view)
    }

    override fun onBindViewHolder(holder: HoldingViewHolder, position: Int) {
        val item = holdings[position]
        holder.bind(item, position)
    }

    override fun getItemCount(): Int = holdings.size

    inner class HoldingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val symbolText: TextView = itemView.findViewById(R.id.symbolText)
        private val quantityText: TextView = itemView.findViewById(R.id.quantityText)
        private val ltpText: TextView = itemView.findViewById(R.id.ltpText)
        private val expandedLayout: View = itemView.findViewById(R.id.expandedLayout)

        fun bind(item: Holding, position: Int) {
            symbolText.text = item.symbol
            quantityText.text = "Qty: ${item.quantity}"
            ltpText.text = "LTP: ₹${item.ltp}"

            // Toggle UI
            expandedLayout.visibility = if (expandedState.contains(position)) View.VISIBLE else View.GONE

            itemView.setOnClickListener {
                if (expandedState.contains(position)) {
                    expandedState.remove(position)
                } else {
                    expandedState.add(position)
                }
                notifyItemChanged(position)
            }
        }
    }
}